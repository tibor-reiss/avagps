from os import environ


HEARTBEAT = environ.get('HEARTBEAT')
